import java.io.IOException;
import java.util.Scanner;

public class exitToMainMenu {
    public static void main() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("If you want to exit to the main menu press y");
        String movieExit = sc.nextLine();
        if ("y".equals(movieExit)) {
            MainMenu.createMainMenu();
        }
    }
}
