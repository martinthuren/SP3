import java.io.IOException;

public class seriesCategories {
    public static void main() throws IOException {
        System.out.println("Here are the categories to choose from");
        System.out.println("Talk-show" + "\n" + "Documentary" + "\n" + "Crime" + "\n" + "Drama" + "\n" + "Action" + "\n" + "Adventure"
                + "\n" + "Drama" + "\n" + "Comedy" + "\n" + "Fantasy" + "\n" + "Animation" + "\n" + "Horror" + "\n" + "Sci-fi" + "\n" + "War" + "\n" + "Thriller" + "\n" + "Mystery" + "\n" + "Biography" + "\n" + "History" + "\n" + "Family" + "\n" + "Western" + "\n" + "Romance" + "\n" + "Sport");
        System.out.println("Write the given category you want to watch, to see which series there is");
    }
}
