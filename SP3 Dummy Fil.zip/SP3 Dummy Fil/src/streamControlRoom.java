import java.io.IOException;
import java.util.ArrayList;

public class streamControlRoom {

    //static ArrayList<String> movie; signe

        public static void main(String[] args) throws IOException {


            //movie = getMovieList.createMovieList(); signe
            AccountStart.startMenu();
            MainMenu.createMainMenu();

        }
}
