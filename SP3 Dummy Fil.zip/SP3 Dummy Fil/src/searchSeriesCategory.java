import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class searchSeriesCategory {

    public static void main() throws IOException {

        Scanner cat = new Scanner(System.in);
        BufferedReader in = new BufferedReader(new FileReader("/Users/martinthuren/Desktop/Datamatiker projekter/seriesList.txt"));
        String f = "/Users/martinthuren/Desktop/Datamatiker projekter/seriesList.txt";
        String input = cat.nextLine();
        while ((f = in.readLine()) != null) {
            if (f.contains(input)) {
                System.out.println(f);
            }
        }
    }
}

