import java.io.*;
import java.util.Scanner;
//virker ikke

public class ChooseFilmFromList {
    //public static void main() throws IOException {
    public static void main(String[] args) throws IOException {

        Scanner sc = new Scanner(System.in);
        BufferedReader br = new BufferedReader(new FileReader("/Users/martinthuren/Desktop/Datamatiker projekter/movieList.txt"));
        for (String line; (line = br.readLine()) != null; ) {
            System.out.print(line + "\n");


            // not found
            //List<String> list = new ArrayList<>();
            // while(sc.hasNextLine()){
            // list.add(sc.nextLine());
        }
        br.close();
        playMovieCategory.main();
    }

}


