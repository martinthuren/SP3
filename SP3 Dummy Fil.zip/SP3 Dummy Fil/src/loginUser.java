public class loginUser {
//ikke lavet færdig, skal kunne bruges til at gemme login oplysninger
}