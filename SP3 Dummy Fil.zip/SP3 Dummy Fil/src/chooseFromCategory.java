import java.io.IOException;
import java.util.Scanner;

public class chooseFromCategory {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String choice = sc.nextLine();
        switch (choice) {
            case "Crime":
                System.out.println("Monday");
                break;
            case "Drama":
                System.out.println("Tuesday");
                break;
            case "Biography":
                System.out.println("Wednesday");
                break;
            case "Sport":
                System.out.println("Thursday");
                break;
            case "History":
                System.out.println("Friday");
                break;
            case "Romance":
                System.out.println("Saturday");
                break;
            case "War":
                System.out.println("Sunday");
                break;
            case "Mystery":
                System.out.println("Monday");
                break;
            case "Adventure":
                System.out.println("Tuesday");
                break;
            case "Family":
                System.out.println("Wednesday");
                break;
            case "Fantasy":
                System.out.println("Thursday");
                break;
            case "Thriller":
                System.out.println("Friday");
                break;
            case "Horror":
                System.out.println("Saturday");
                break;
            case "Film-Noir":
                System.out.println("Sunday");
                break;
            case "Action":
                System.out.println("Monday");
                break;
            case "Sci-fi":
                System.out.println("Tuesday");
                break;
            case "Comedy":
                System.out.println("Wednesday");
                break;
            case "Musical":
                System.out.println("Thursday");
                break;
            case "Western":
                System.out.println("Friday");
                break;
            case "Music":
                System.out.println("Saturday");
                break;
        }
    }
}
