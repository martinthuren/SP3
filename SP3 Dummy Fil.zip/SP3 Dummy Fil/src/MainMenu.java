import java.io.IOException;
import java.util.Scanner;

public class MainMenu extends AccountStart {
    public static void createMainMenu() throws IOException {
        Scanner use = new Scanner(System.in);
        System.out.println("****************************************");
        System.out.println("Here is your following options to choose from");
        System.out.println("1. Choose between all movies and series");       //vis alle film //underkategori spil den valgte film //gem filmen knap
        System.out.println("2. Choose from between movie categories");   //skal kunne sortere på kategori //underkategori spil den valgte film
        System.out.println("3. Choose from between series categories");
        System.out.println("4. List of watched movies"); //liste af sete film
        System.out.println("5. List of saved movies");   //liste af gemte film
        System.out.println("6. Exit");                   //gå ud af programmet
        System.out.println("****************************************");
        String userChoice = use.nextLine();
        switch (userChoice) {
            case "1":
                System.out.println("What do you want to see? Movies or series?");
                String s = use.nextLine();
            case "Movies":
                getMovieList.main();
            case "Series":
                getSeriesList.main();
                break;

            case "2":
                movieCategories.main();
                    searchMovieCategory.main();
                    playMovieCategory.main();
            case "3":
                seriesCategories.main();
                searchSeriesCategory.main();
                playSeriesCategory.main();
                break;

            case "4":
                System.out.println("List of watched movies");
                break;
            case "5":
                System.out.println("List of saved movies");
                break;
            case "6":
                System.out.println("You are exiting StreamFix");
                break;
        }
    }
}
