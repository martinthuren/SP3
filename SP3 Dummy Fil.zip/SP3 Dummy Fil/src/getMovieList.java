import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class getMovieList {

    // public static void main() throws IOException {
        /*
        BufferedReader br = new BufferedReader(new FileReader("/Users/martinthuren/Desktop/Datamatiker projekter/movieList.txt"));
        for (String line; (line = br.readLine()) != null;) {
            System.out.print(line + "\n");
        }
        br.close();
        playMovieCategory.main();
    }
}
*/

    //class playMovieFromArrayList {
    public static void main() {

        // create an empty array list with an initial capacity
        ArrayList<String> movieList = new ArrayList<String>(100);
        Scanner input = new Scanner(System.in);

        // use add() method to add elements in the list
        movieList.add("0. The Godfather; 1972; Crime, Drama; 9,2; ");
        movieList.add("1.  The Shawshank Redemption; 1994; Drama; 9,3;");
        movieList.add("2.  Schindler's List; 1993; Biography, Drama, History; 8,9;");
        movieList.add("3.  Raging Bull; 1980; Biography, Drama, Sport; 8,2;");
        movieList.add("4.  Casablanca; 1942; Drama, Romance, War; 8,5;");
        movieList.add("5.  Citizen Kane; 1941; Drama, Mystery; 8,4;");
        movieList.add("6.  Gone With The Wind; 1939; Drama, History, Romance; 8,2;");
        movieList.add("7.  The Wizard Of Oz; 1939; Adventure, Family, Fantasy; 8,0;");
        movieList.add("8.  One Flew Over The Cuckoo's Nest; 1975; Drama; 8,7;");
        movieList.add("9. Lawrence Of Arabia; 1962; Adventure, Biography, Drama;8,3;");
        movieList.add("10. Vertigo; 1958; Mystery, Romance, Thriller; 8,3;");
        movieList.add("11. Psycho; 1960; Horror, Mystery, Thriller; 8,5;");
        movieList.add("12. The Godfather part II; 1974; Crime, Drama; 9;");
        movieList.add("13. On The Waterfront; 1954; Crime, Drama, Thriller; 8,2;");
        movieList.add("14. Sunset Boulevard; 1950; Drama, Film-Noir; 8,4;");
        movieList.add("15. Forrest Gump; 1994; Drama, Romance; 8,8;");
        movieList.add("16. The Sound Of Music; 1965; Biography, Drama, Family, Musical; 8,0;");
        movieList.add("17. 12 Angry Men; 1957; Crime, Drama; 8,9;");
        movieList.add("18. West Side Story; 1961; Crime, Drama; 7,6;");
        movieList.add("19. Star Wars; 1977; Action, Adventure, Family; 8,6;");
        movieList.add("20. 2001 A Space Odyssey; 1968; Adventure, Sci-fi; 8,3;");
        movieList.add("21. ET; 1982; Family, Sci-fi; 7,9;");
        movieList.add("22. The Silence Of The Lambs; 1991;Crime, Drama, Thriller; 8,6;");
        movieList.add("23. Chinatown; 1974; Drama, Mystery, Thriller; 8,2;");
        movieList.add("24. The Bridge Over The River Kwai; 1957; Adventure, Drama, War; 8,2;");
        movieList.add("25. Singin' In The Rain; 1952; Comedy, Musical, Romance; 8,3;");
        movieList.add("26. It's A Wonderful Life; 1946; Drama, Family, Fantasy; 8,6;");
        movieList.add("27. Dr. Strangelove Or How I Learned To Stop Worrying And Love The Bomb; 1964; Comedy, War; 8,4;");
        movieList.add("28. Some Like It Hot; 1959; Comedy, Romance; 8,2; ");
        movieList.add("29. Ben Hur; 1959; Adventure, Drama, History; 8,1;");
        movieList.add("30. Apocalypse Now; 1979; Drama, War; 8,5;");
        movieList.add("31. Amadeus; 1984; Biography, Drama, History; 8,3;");
        movieList.add("32. Lord Of The Rings - The Return Of The King; 2003; Action, Adventure, Drama; 8,9;");
        movieList.add("33. Gladiator; 2000; Action, Adventure, Drama; 8,5;");
        movieList.add("34. Titanic; 1997; Drama, Romance; 7,8;");
        movieList.add("35. From Here To Eternity; 1953; Drama, Romance, War; 7,7;");
        movieList.add("36. Saving Private Ryan; 1998; Drama, War; 8,6;");
        movieList.add("37. Unforgiven; 1992; Drama, Western; 8,2;");
        movieList.add("38. Raiders Of The Lost Ark; 1981; Action, Adventure; 8,5;");
        movieList.add("39. Rocky; 1976; Drama, Sport; 8,1;");
        movieList.add("40. A Streetcar Named Desire; 1951; Drama; 8,0;");
        movieList.add("41. A Philadelphia Story; 1940; Comedy, Romance; 8,0;");
        movieList.add("42. To Kill A Mockingbird; 1962; Crime, Drama; 8,3;");
        movieList.add("43. An American In Paris; 1951; Drama, Musical, Romance; 7,2;");
        movieList.add("44. The Best Years Of Our Lives; 1946; Drama, Romance, War; 8,1;");
        movieList.add("45. My Fair Lady; 1964; Drama, Family, Musical; 7,9;");
        movieList.add("46. A Clockwork Orange; 1971; Crime, Drama, Sci-fi; 8,3;");
        movieList.add("47. Doctor Zhivago; 1965; Drama, Romance, War; 8,0;");
        movieList.add("48. The Searchers; 1956; Adventure, Drama, Western; 8,0;");
        movieList.add("49. Jaws; 1975; Adventure, Drama, Thriller; 8,0;");
        movieList.add("50. Patton; 1970; Biography, Drama, War; 8,0;");
        movieList.add("51. Butch Cassidy And The Sundance Kid; 1969; Biography, Crime, Drama; 8,1;");
        movieList.add("52. The Treasure Of The Sierra Madre; 1948; Adventure, Drama, Western; 8,3;");
        movieList.add("53. The Good, The Bad And The Ugly; 1966; Western; 8,9;");
        movieList.add("54. The Apartment; 1960; Comedy, Drama, Romance; 8,3;");
        movieList.add("55. Platoon; 1986; Drama, War; 8,1;");
        movieList.add("56. High Noon; 1952; Action, Drama, Thriller; 8,0;");
        movieList.add("57. Braveheart; 1995; Biography, Drama, History; 8,4;");
        movieList.add("58. Dances With Wolves; 1990; Adventure, Drama, Western; 8,0;");
        movieList.add("59. Jurassic Park; 1993; Adventure, Sci-fi, Thriller; 8,1;");
        movieList.add("60. The Exorcist; 1973; Horror; 8,0;");
        movieList.add("61. The Pianist; 2002; Biography, Drama, Music; 8,5;");
        movieList.add("62. Goodfellas; 1990; Crime, Drama; 8,7;");
        movieList.add("63. The Deer Hunter; 1978; Drama, War; 8,1;");
        movieList.add("64. All Quiet On The Western Front; 1930; Drama, War; 8,1;");
        movieList.add("65. Bonny And Clyde; 1967; Action, Biography, Crime; 7,9;");
        movieList.add("66. The French Connection; 1971; Action, Crime, Drama; 7,8;");
        movieList.add("67. City Lights; 1931; Comedy, Drama, Romance; 8,5;");
        movieList.add("68. It Happened One Night; 1934; Comedy, Romance; 8,1;");
        movieList.add("69. A Place In The Sun; 1951; Drama, Romance; 7,8;");
        movieList.add("70. Midnight Cowboy; 1969; Drama; 7,9;");
        movieList.add("71. Mr Smith Goes To Washington; 1939; Comedy, Drama; 8,2;");
        movieList.add("72. Rain Man; 1988; Drama; 8,0;");
        movieList.add("73. Annie Hall; 1977; Comedy, Romance; 8,0;");
        movieList.add("74. Fargo; 1996; Crime, Drama, Thriller; 8,1;");
        movieList.add("75. Giant; 1956; Drama, Western; 7,7;");
        movieList.add("76. Shane; 1953; Drama, Western; 7,7;");
        movieList.add("77. Grapes Of Wrath; 1940; Drama, History; 8,1;");
        movieList.add("78. The Green Mile; 1999; Crime, Drama, Fantasy; 8,5;");
        movieList.add("79. Close Encounters; 1977; Drama, Sci-fi; 7,7;");
        movieList.add("80. Nashville; 1975; Comedy, Drama, Music; 7,8;");
        movieList.add("81. Network; 1976; Drama; 8,1;");
        movieList.add("82. The Graduate; 1967; Comedy, Drama, Romance; 8,0;");
        movieList.add("83. American Graffiti; 1973; Comedy, Drama; 7,5;");
        movieList.add("84. Pulp Fiction; 1994; Crime, Drama; 8,9;");
        movieList.add("85. Terms of Endearment; 1983; Comedy, Drama; 7,4; ");
        movieList.add("86. Good Will Hunting; 1997; Drama, Romance; 8,3;");
        movieList.add("87. The African Queen; 1951; Adventure, Drama, Romance; 7,9;");
        movieList.add("88. Stagecoach; 1939; Adventure, Western; 7,9;");
        movieList.add("89. Mutiny On The Bounty; 1935; Adventure, Biography, Drama; 7,8;");
        movieList.add("90. The Great Dictator; 1940; Comedy, Drama, War; 8,5;");
        movieList.add("91. Double Indemnity; 1944; Crime, Drama, Film-Noir; 8,3;");
        movieList.add("92. The Maltese Falcon; 1941; Film-Noir, Mystery; 8,1;");
        movieList.add("93. Wuthering Heights; 1939; Drama, Romance; 7,7;");
        movieList.add("94. Taxi Driver; 1976; Crime, Drama; 8,3;");
        movieList.add("95. Rear Window; 1954; Mystery, Thriller; 8,5;");
        movieList.add("96. The Third Man; 1949; Film-Noir, Mystery, Thriller; 8,2;");
        movieList.add("97. Rebel Without A Cause; 1955; Drama; 7,8;");
        movieList.add("98. North By Northwest; 1959; Adventure, Mystery, Thriller; 8,3;");
        movieList.add("99. Yankee Doodle Dandy; 1942; Biography, Drama, Musical; 7,7;");

        // let us print all the elements available in list
        for (String film : movieList) {
            System.out.println(film);
        }

        // retrieves element
        System.out.println("Please enter the number of the movie you want to see");
        int x = input.nextInt();
        String retval = movieList.get(x);
        System.out.println("You're now playing " + retval);
        try {
            exitToMainMenu.main();
        } catch (Exception ex) {
            System.out.println("Internal error");
        }
        /*System.out.println("If you want to exit to the main menu press y");
        String userChoice = input.nextLine();
        if ("movieExit".equals(userChoice)) {
                mainMenu.main();*/
            }
        }

