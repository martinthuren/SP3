import java.io.IOException;
import java.util.Scanner;

public class playMovieCategory {
    static Scanner sc = new Scanner(System.in);

    public static void main() throws IOException {
        System.out.println("Choose the specific film you wanna see by writing its name");
        String name = sc.nextLine();
        System.out.println(name + " is now playing, enjoy the movie!");
        exitToMainMenu.main();
            }
        }

