import java.io.*;
import java.util.Scanner;

public class searchMovieCategory {
    public static void main() throws IOException {

        Scanner cat = new Scanner(System.in);
        BufferedReader in = new BufferedReader(new FileReader("/Users/martinthuren/Desktop/Datamatiker projekter/movieList.txt"));
        String f = "/Users/martinthuren/Desktop/Datamatiker projekter/movieList.txt";
        String input = cat.nextLine();
        while ((f = in.readLine()) != null) {
            if (f.contains(input)) {
                System.out.println(f);
            }
        }
    }
}
