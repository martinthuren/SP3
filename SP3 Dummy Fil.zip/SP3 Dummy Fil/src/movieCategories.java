import java.io.IOException;

public class movieCategories {
    public static void main() throws IOException {

        System.out.println("Here are the categories to choose from");
        System.out.println("Crime" + "\n" + "Drama" + "\n" + "Biography" + "\n" + "Sport" + "\n" + "History" + "\n" + "Romance" + "\n" + "War" + "\n" + "Mystery" + "\n" + "Adventure" +
                "\n" + "Family" + "\n" + "Fantasy" + "\n" + "Thriller" + "\n" + "Horror" + "\n" + "Film-Noir" + "\n" + "Action" + "\n" + "Sci-fi" + "\n" + "Comedy" + "\n" + "Musical" + "\n" + "Western" + "\n" + "Music");
        System.out.println("Write the given category you want to watch, to see which films there is");
    }
}
